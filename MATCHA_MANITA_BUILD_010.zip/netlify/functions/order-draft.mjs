import {validateItems} from './_lib/catalog.mjs';
const json=(body,status=200)=>Response.json(body,{status,headers:{'cache-control':'no-store'}});
export default async(req)=>{
 if(req.method!=='POST')return json({error:'method_not_allowed'},405);
 let body;try{body=await req.json()}catch{return json({error:'invalid_json'},400)}
 const zip=String(body?.zip||'').trim();if(!/^\d{5}$/.test(zip))return json({error:'invalid_zip'},400);
 const checked=validateItems(body?.items);if(checked.error)return json(checked,400);
 const notes=String(body?.notes||'').trim().slice(0,500);
 const draftId=`MM-${Date.now().toString(36).toUpperCase()}`;
 return json({ok:true,draftId,status:'draft',zip,subtotal:checked.subtotal,currency:'USD',notes,createdAt:new Date().toISOString(),message:'Ephemeral review draft created. Production persistence is not connected.'},201);
};
