export default async () => {
  const provider=Netlify.env.get('POS_PROVIDER') || 'local';
  const connected=provider!=='local' && Boolean(Netlify.env.get('POS_API_BASE_URL') && Netlify.env.get('POS_API_KEY'));
  return Response.json({ok:true,provider,connected,mode:connected?'authorized-provider':'local-review'}, {headers:{'cache-control':'no-store'}});
};
