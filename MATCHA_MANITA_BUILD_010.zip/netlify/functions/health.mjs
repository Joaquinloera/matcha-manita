export default async () => Response.json({ok:true,service:'matcha-manita-api',build:'010',time:new Date().toISOString()},{headers:{'cache-control':'no-store'}});
