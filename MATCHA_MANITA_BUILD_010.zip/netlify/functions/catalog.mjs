import catalog from '../../data/catalog.json' with { type: 'json' };
export default async (req) => {
  if (req.method !== 'GET') return Response.json({error:'method_not_allowed'},{status:405});
  return Response.json(catalog,{headers:{'cache-control':'public, max-age=60'}});
};
