# BUILD 004 server functions

- `health.mjs`: deployment/API health check.
- `catalog.mjs`: local normalized catalog endpoint.
- `order-review.mjs`: validates a cart payload for review; it does not charge or submit an order.
- `provider-status.mjs`: reports whether an optional authorized provider is configured without exposing credentials.

BUILD 004 runs with **zero environment variables** in local mode.
Future provider secrets must be configured in the hosting environment, never committed to GitHub.
