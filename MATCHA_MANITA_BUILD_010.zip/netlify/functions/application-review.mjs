const json=(body,status=200)=>Response.json(body,{status,headers:{'cache-control':'no-store'}});
export default async(req)=>{
 if(req.method!=='POST')return json({error:'method_not_allowed'},405);
 let b;try{b=await req.json()}catch{return json({error:'invalid_json'},400)}
 const name=String(b?.name||'').trim(),email=String(b?.email||'').trim().toLowerCase();
 if(name.length<2||!/^\S+@\S+\.\S+$/.test(email))return json({error:'invalid_application'},400);
 return json({ok:true,status:'reviewed',profile:{name,email},message:'Application data validated. No production account has been created.'});
};
