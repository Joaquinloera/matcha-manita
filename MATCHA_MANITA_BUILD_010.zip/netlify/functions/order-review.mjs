import {validateItems} from './_lib/catalog.mjs';
const json=(body,status=200)=>Response.json(body,{status,headers:{'cache-control':'no-store'}});
export default async(req)=>{
 if(req.method!=='POST')return json({error:'method_not_allowed'},405);
 let body;try{body=await req.json()}catch{return json({error:'invalid_json'},400)}
 const zip=String(body?.zip||'').trim(); if(!/^\d{5}$/.test(zip))return json({error:'invalid_zip'},400);
 const checked=validateItems(body?.items); if(checked.error)return json(checked,400);
 return json({ok:true,status:'review_only',zip,items:checked.normalized,subtotal:checked.subtotal,currency:'USD',message:'Validated against server catalog for review only. No payment charged and no order submitted.'});
};
