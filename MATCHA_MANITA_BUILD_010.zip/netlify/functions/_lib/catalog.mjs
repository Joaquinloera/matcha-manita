export const catalog=[
{id:1,category:'Flower',name:'Manita OG',price:50,active:true,inventory:24},
{id:2,category:'Flower',name:'Green Goddess',price:48,active:true,inventory:18},
{id:3,category:'Pre-Rolls',name:'Golden Roll',price:24,active:true,inventory:40},
{id:4,category:'Infused',name:'Emerald Infused',price:32,active:true,inventory:16},
{id:5,category:'Concentrates',name:'Live Rosin',price:45,active:true,inventory:12},
{id:6,category:'Vapes',name:'Live Resin Vape',price:40,active:true,inventory:22},
{id:7,category:'Edibles',name:'Manita Gummies',price:28,active:true,inventory:30},
{id:8,category:'Beverages',name:'Infused Matcha',price:18,active:true,inventory:36},
{id:9,category:'Topicals',name:'Green Relief',price:35,active:true,inventory:14},
{id:10,category:'Accessories',name:'MM Grinder',price:30,active:true,inventory:20},
{id:11,category:'Flower',name:'Gelato 33',price:52,active:true,inventory:15},
{id:12,category:'Flower',name:'Blue Dream',price:46,active:true,inventory:19}
];
export function validateItems(items){
 if(!Array.isArray(items)||!items.length)return {error:'empty_order'};
 if(items.length>100)return {error:'too_many_items'};
 let subtotal=0; const normalized=[];
 for(const item of items){
  const id=Number(item?.id),qty=Number(item?.qty),product=catalog.find(p=>p.id===id&&p.active);
  if(!product||!Number.isInteger(qty)||qty<1||qty>25)return {error:'invalid_item'};
  if(qty>product.inventory)return {error:'insufficient_inventory',productId:id,available:product.inventory};
  subtotal+=product.price*qty; normalized.push({id,qty,name:product.name,unitPrice:product.price,lineTotal:product.price*qty});
 }
 return {normalized,subtotal};
}
