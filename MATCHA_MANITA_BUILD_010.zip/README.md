# Matcha Manita
Upload-ready static application foundation for the Matcha Manita storefront.

## Deploy
Netlify publish directory: `.`
No build command required.

## Included
Responsive animated home, live catalog filtering/search/sort, cart with persistence, delivery ZIP interface, signup/application form, local profile recognition, login interface, age gate, deals/about sections, mobile navigation, and master Matcha Manita artwork.

## Production backend note
This foundation intentionally does not fake server-side authentication, payments, inventory, or order fulfillment. Those require real production services/credentials and should be connected in the next backend phase.

BUILD 002 CHECKPOINT
- GitHub index.html checkpoint preserved
- styles.css responsive motion UI
- app.js interactive navigation, catalog, cart, forms
- Netlify SPA routing
- MATCHA MANITA branding locked

## BUILD 004 backend foundation

BUILD 004 adds a deployable Netlify Functions layer under `/api/*`:

- `/api/health`
- `/api/catalog`
- `/api/order-review`
- `/api/provider-status`

The default provider is `local`, so **no environment variables are required** for this build. The order-review endpoint validates order shape and ZIP only; it does not charge cards or submit regulated-product orders.

Optional future authorized-provider variables (do not create until needed):

- `POS_PROVIDER`
- `POS_API_BASE_URL`
- `POS_API_KEY`

Never place secrets in `app.js`, HTML, ZIP documentation, or GitHub source.

## BUILD 005
Adds server-side cart/catalog validation, inventory bounds, ephemeral order drafts, application validation, and frontend API-backed order review. Production persistence, authentication, regulated-commerce fulfillment, and payment processing remain intentionally disconnected until authorized services are configured.

## BUILD 006
- Application submissions now call `/api/application-review` before being saved locally.
- The bag checkout control now hands off directly to the checkout/review section.
- Footer service status checks `/api/health` and `/api/provider-status` so the UI distinguishes a working backend from an unavailable preview.
- No production provider credentials, payment processing, or regulated order submission are enabled.

## BUILD 007
- Restores validated local application/account state after refresh.
- Local login recognizes only server-validated application records.
- Checkout restores saved draft ZIP/receipt state.
- Review flow validates inventory then creates an ephemeral server draft receipt.
- Production authentication, payment, regulated order submission, and provider connectivity remain disabled until authorized services are connected.
- No secrets or environment variables are required for this checkpoint.


## BUILD 008
- Adds 8-second API request timeout/abort handling.
- Adds explicit local preview session state and clear-session control.
- Drafts store cart fingerprints and flag when the bag changed after review.
- Delivery notes are included in ephemeral draft receipts (max 500 chars).
- Adds clear-saved-draft control without clearing the cart.
- Review button is disabled during server validation to prevent duplicate taps.


## BUILD 009
- Adds five-entry local draft history.
- Preserves bag/draft state across network failures.
- Adds friendly timeout/offline/inventory-change recovery messaging.
- Revalidates inventory before creating each draft receipt.
- Adds online/offline recovery hooks and service-health refresh.
- No production payment or regulated-order submission is enabled.

## BUILD 010
- Refactored the frontend into one authoritative event-handler/state path; removed stacked BUILD 006-009 overrides.
- `/api/catalog` is now the primary inventory source with a local fallback for offline/static preview.
- Product cards and bag quantities are inventory-aware and unavailable items are disabled.
- Cart is reconciled against refreshed server inventory before draft review.
- Draft receipts are invalidated visually when the bag changes.
- Netlify provider configuration now reads server-side values through `Netlify.env.get()`.
- Provider status reports an explicit `connected` boolean; local mode does not pretend to be a production provider.
- No production payment, regulated order submission, or provider connection is enabled by this checkpoint.
